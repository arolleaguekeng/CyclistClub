CREATE TABLE balades
(
    id_balade int IDENTITY(100,5055) PRIMARY KEY NOT NULL,
    date_balade VARCHAR(30) NOT NULL, 
    tarrif  NUMBER  NOT NULL,
	lieux_depart VARCHAR(30),
	lieux_arrivee VARCHAR(30),
);