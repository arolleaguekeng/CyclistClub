 CREATE TABLE reservations 
 (
    id_reservation VARCHAR(30) PRIMARY KEY NOT NULL,
	id_membre VARCHAR(30) NOT NULL 
    velo INT,
    membre INT
 );