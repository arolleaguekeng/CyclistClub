CREATE TABLE covoiturage
(
    id_vehicule int IDENTITY(100,5055) PRIMARY KEY NOT NULL,
    nbre_place  INT  NOT NULL
);