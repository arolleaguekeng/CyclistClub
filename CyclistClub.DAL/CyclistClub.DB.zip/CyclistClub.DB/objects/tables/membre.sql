CREATE TABLE membres 
 (
    id_membre VARCHAR(30) PRIMARY KEY NOT NULL,
    nom VARCHAR(30),
    telephone INT NOT NULL,
    password VARCHAR(30),
    picture VARCHAR(100)
 );

