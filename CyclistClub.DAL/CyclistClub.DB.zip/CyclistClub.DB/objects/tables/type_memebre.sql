 CREATE TABLE type_membre 
 (
	intitule_type VARCHAR(20)PRIMARY KEY NOT NULL
 );