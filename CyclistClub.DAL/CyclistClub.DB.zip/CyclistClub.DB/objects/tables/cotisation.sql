CREATE TABLE cotisations
 (
    id_cotisation int IDENTITY(100,5055) PRIMARY KEY NOT NULL,
	montent_cotisation INT,
    date_cotisation DATE, 
	id_membre VARCHAR(30)
);