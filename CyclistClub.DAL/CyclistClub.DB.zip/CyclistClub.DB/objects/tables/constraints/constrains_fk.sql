ALTER TABLE covoiturages 
ADD
CONSTRAINT fk_vehicule FOREIGN KEY (id_vehicule) REFERENCES vehicules(id_vehicule);



ALTER TABLE membres 
ADD
CONSTRAINT fk_type_membre FOREIGN KEY (id_membre) REFERENCES type_membre(id_membre);



ALTER TABLE reservations 
ADD
CONSTRAINT fk_client_reservation FOREIGN KEY (id_membre) REFERENCES membres(id_membre);