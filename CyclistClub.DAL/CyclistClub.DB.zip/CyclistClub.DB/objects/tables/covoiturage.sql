CREATE TABLE covoiturage
(
    id_covoiturage int IDENTITY(100,5055) PRIMARY KEY NOT NULL,
    place_membre  INT  NOT NULL,
    place_velo  INT  NOT NULL,
    id_vehicule INT NOT NULL
);